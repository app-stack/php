<?php
    echo 'Page d\'Accueil';
?>
