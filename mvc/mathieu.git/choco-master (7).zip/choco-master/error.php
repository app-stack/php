<?php
    echo 'Erreur 404
    la page n\'existe pas';
?>
