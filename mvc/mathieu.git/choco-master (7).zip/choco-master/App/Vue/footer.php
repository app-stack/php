<?php ob_start();?>
<ul>
    <li>Contact</li>
    <li>Conditions générales</li>
    <li>Aide</li>
</ul>
<?php $footer = ob_get_clean();?>